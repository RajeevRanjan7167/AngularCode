﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperheroesTechTest.Services.TestAPI
{
    public static class ConstantMessages
    {
        public static class Messages
        {            
            public const string WinnerTestCaseMessages = "We have a winner : superman";
        }
    }
}
