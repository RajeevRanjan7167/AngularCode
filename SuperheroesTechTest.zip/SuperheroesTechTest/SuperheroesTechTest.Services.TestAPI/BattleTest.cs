﻿using SuperheroesTechTest.Services.BattleAPI.Controllers;
using SuperheroesTechTest.Services.BattleAPI.Repository;

namespace SuperheroesTechTest.Services.TestAPI
{
    public class BattleTest
    {
        private readonly IBattleReposity _battleReposity;

        public BattleTest(IBattleReposity battleReposity)
        {
            this._battleReposity = battleReposity;
        }

        [Fact]
        public async Task Test1()
        {
            BattleController battleController = new BattleController(_battleReposity);
            var info = await battleController.BattleInfo("Batman", "Joker");

            Assert.NotNull(info);
            Assert.Matches(ConstantMessages.Messages.WinnerTestCaseMessages, info.ToString());
        }
    }

}
