﻿using Microsoft.AspNetCore.Mvc;
using SuperheroesTechTest.Services.BattleAPI.Helpper;
using SuperheroesTechTest.Services.BattleAPI.Models.DTO;
using SuperheroesTechTest.Services.BattleAPI.Repository;

namespace SuperheroesTechTest.Services.BattleAPI.Controllers
{
    [Route("api/battle")]
    public class BattleController : ControllerBase
    {
        private readonly IBattleReposity _battleReposity;

        public BattleController(IBattleReposity battleReposity)
        {
            this._battleReposity = battleReposity;
        }

        [HttpGet]
        public async Task<IActionResult> BattleInfo(string character, string rival)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(character) || string.IsNullOrWhiteSpace(rival))
                    return NotFound();

                var battleDtos = await _battleReposity.GetBattleInfo(character, rival);
                return Ok(ConstantMessages.Messages.WinnerMessages + battleDtos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
    }
}
