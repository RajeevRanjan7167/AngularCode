﻿namespace SuperheroesTechTest.Services.BattleAPI.Helpper.IServices
{
    public interface IConfigManager
    {
        string BattleConnection { get; }
    }
}
