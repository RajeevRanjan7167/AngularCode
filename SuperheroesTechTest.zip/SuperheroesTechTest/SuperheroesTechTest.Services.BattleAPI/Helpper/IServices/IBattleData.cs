﻿using SuperheroesTechTest.Services.BattleAPI.Models;
using SuperheroesTechTest.Services.BattleAPI.Models.DTO;

namespace SuperheroesTechTest.Services.BattleAPI.Helpper.IServices
{
    public interface IBattleData
    {
        Task<IEnumerable<BattleDto>> GetBettleResultAsync(string uri);
    }
}
