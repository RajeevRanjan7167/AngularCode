﻿namespace SuperheroesTechTest.Services.BattleAPI.Helpper
{
    public static class ConstantMessages
    {
        public static class Messages {
            public const string ValidationError = "Characters of the same type should not fight";
            public const string RecordCountError = "One of the charachter in the battle does not exist!!!";
            public const string WinnerMessages = "We have a winner ";
        }
    }
}
