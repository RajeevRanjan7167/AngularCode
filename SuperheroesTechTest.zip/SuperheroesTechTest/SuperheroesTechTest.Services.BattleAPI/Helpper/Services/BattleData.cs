﻿using AutoMapper;
using Newtonsoft.Json;
using SuperheroesTechTest.Services.BattleAPI.Helpper.IServices;
using SuperheroesTechTest.Services.BattleAPI.Models;
using SuperheroesTechTest.Services.BattleAPI.Models.DTO;

namespace SuperheroesTechTest.Services.BattleAPI.Helpper.Services
{
    public class BattleData : IBattleData
    {
        private IMapper _mapper;
        public BattleData(IMapper mapper)
        {
            _mapper = mapper;
        }
     
        public async Task<IEnumerable<BattleDto>> GetBettleResultAsync(string uri)
        {
            HttpClient httpClient = new();
            var response = await httpClient.GetAsync(uri);
            var responseContent = await response.Content.ReadAsStringAsync();
            var responseObject = JsonConvert.DeserializeObject<Battles>(responseContent);
            IEnumerable<Battle> battles = responseObject.battles;
            return _mapper.Map<List<BattleDto>>(battles);
        }
    }
}
