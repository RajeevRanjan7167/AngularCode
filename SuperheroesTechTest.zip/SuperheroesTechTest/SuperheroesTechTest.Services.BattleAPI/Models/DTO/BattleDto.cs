﻿
namespace SuperheroesTechTest.Services.BattleAPI.Models.DTO
{
    public class BattleDto
    {
        public string? Name { get; set; }
        public decimal? Score { get; set; }
        public string? Type { get; set; }
        public string? Weakness { get; set; }
    }
}
