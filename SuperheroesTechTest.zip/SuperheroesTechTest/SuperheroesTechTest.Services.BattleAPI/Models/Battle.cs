﻿using Newtonsoft.Json.Converters;
using System.Text.Json.Serialization;

namespace SuperheroesTechTest.Services.BattleAPI.Models
{
    public class Battle
    {
        public string? Name { get; set; }
        public decimal? Score { get; set; }
        public string? Type { get; set; }
        public string? Weakness { get; set; }
    }

    public class Battles
    {
        public List<Battle> battles { get; set; }
    }
}
