﻿using SuperheroesTechTest.Services.BattleAPI.Models;
using SuperheroesTechTest.Services.BattleAPI.Models.DTO;

namespace SuperheroesTechTest.Services.BattleAPI.Repository
{
    public interface IBattleReposity
    {
        Task<string> GetBattleInfo(string character,string rival);
        bool ValicateInfo(List<BattleDto> battles);
    }
}
