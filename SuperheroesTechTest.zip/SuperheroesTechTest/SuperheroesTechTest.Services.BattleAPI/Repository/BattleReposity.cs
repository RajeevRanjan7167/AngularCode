﻿using AutoMapper;
using SuperheroesTechTest.Services.BattleAPI.Helpper;
using SuperheroesTechTest.Services.BattleAPI.Helpper.IServices;
using SuperheroesTechTest.Services.BattleAPI.Models.DTO;

namespace SuperheroesTechTest.Services.BattleAPI.Repository
{
    public class BattleReposity : IBattleReposity
    {
        private IMapper _mapper;
        private readonly IConfigManager _configManager;
        private readonly IBattleData _battleData;

        public BattleReposity(IMapper mapper, IConfigManager configManager, IBattleData battleData)
        {
            this._mapper = mapper;
            this._configManager = configManager;
            this._battleData = battleData;
        }

        public async Task<string> GetBattleInfo(string character, string rival)
        {
            string URL_PATH = _configManager.BattleConnection;
            var responseObject = await _battleData.GetBettleResultAsync(URL_PATH);

            var returnVal = string.Empty;
            var records = responseObject.Where(x => x.Name == character || x.Name == rival).ToList();

            if (records?.Count < 2)
                throw new Exception(ConstantMessages.Messages.RecordCountError);
            else
            {
                if (records != null)
                {
                    if (ValicateInfo(records))
                    {
                        var checkWeaknessOfSuperHero = CheckWeakness(records);
                        returnVal = checkWeaknessOfSuperHero[0].Score > checkWeaknessOfSuperHero?[1].Score ? checkWeaknessOfSuperHero?[0].Name : checkWeaknessOfSuperHero?[1].Name;
                    }
                    else
                        throw new Exception(ConstantMessages.Messages.ValidationError);
                }
            }
            if (returnVal == null) return string.Empty;
            return returnVal;
        }

        public bool ValicateInfo(List<BattleDto> battles)
        {
            if (battles[0].Type == battles[1].Type)
                return false;
            else
                return true;
        }

        public List<BattleDto> CheckWeakness(List<BattleDto> battles)
        {
            List<BattleDto> battleChars = new List<BattleDto>();

            battleChars = MapBattles(battleChars, battles);
            var superHeroWeakness = battleChars.SingleOrDefault(x => x.Type?.ToLower().ToString() == "Hero".ToLower().ToString() && !String.IsNullOrEmpty(x.Weakness));
            if (superHeroWeakness != null)
            {
                var result = battleChars.SingleOrDefault(r => r.Name == superHeroWeakness.Name && r.Weakness == superHeroWeakness.Weakness);
                if (result != null)
                {
                    foreach (var item in battleChars)
                    {
                        if (item.Name != result.Name)
                            item.Score++;
                    }
                }
            }
            return battleChars;
        }

        private List<BattleDto> MapBattles(List<BattleDto> newInfo, List<BattleDto> oldInfo)
        {
            foreach (var item in oldInfo)
            {
                BattleDto newBattle = new();
                newBattle.Name = item.Name;
                newBattle.Weakness = item.Weakness;
                newBattle.Type = item.Type;
                newBattle.Score = item.Score;
                newInfo.Add(newBattle);
            }
            return newInfo;
        }
    }
}
