﻿using AutoMapper;
using SuperheroesTechTest.Services.BattleAPI.Models;
using SuperheroesTechTest.Services.BattleAPI.Models.DTO;
namespace SuperheroesTechTest.Services.BattleAPI
{
    public class MappingConfig
    {
        public static MapperConfiguration RegisterMaps()
        {
            var mappingConfig = new MapperConfiguration(config =>
            {
                config.CreateMap<BattleDto, Battle>();
                config.CreateMap<Battle, BattleDto>();
            });
            return mappingConfig;
        }
    }
}
