export interface NavigationItem {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: NavigationItem[];
}

export const NavigationItems: NavigationItem[] = [
  {
    id: 'navigation',
    title: 'Navigation',
    type: 'group',
    icon: 'icon-group',
    children: [
      {
        id: 'dashboard',
        title: 'Dashboard',
        type: 'item',
        url: '/analytics',
        icon: 'feather icon-home'
      }
    ]
  },
  {
    id: 'ui-file-info',
    title: 'Ui File Information',
    type: 'group',
    icon: 'icon-group',
    children: [
      {
        id: 'basic',
        title: 'Files',
        type: 'collapse',
        icon: 'feather icon-file-text',
        children: [
          {
            id: 'fileprocess',
            title: 'File Process',
            type: 'item',
            url: '/files/fileprocess'
          },
          {
            id: 'fileprocess',
            title: 'File Update',
            type: 'item',
            url: '/files/fileupdate'
          }          
        ]
      }
    ]
  },
  {
    id: 'ui-scripts-info',
    title: 'Ui Scripts Information',
    type: 'group',
    icon: 'icon-group',
    children: [
      {
        id: 'basic',
        title: 'Scripts',
        type: 'collapse',
        icon: 'feather icon-layers',
        children: [
          {
            id: 'updateoutput',
            title: 'Update Output',
            type: 'item',
            url: '/scripts/updateoutput'
          },
          {
            id: 'generatescripts',
            title: 'Generate Scripts',
            type: 'item',
            url: '/scripts/generatescripts'
          },
          {
            id: 'createprocedure',
            title: 'Create Procedure',
            type: 'item',
            url: '/scripts/createprocedure'
          }
        ]
      }
    ]
  },
  {
    id: 'ui-scripts-info',
    title: 'Ui SSIS Information',
    type: 'group',
    icon: 'icon-group',
    children: [
      {
        id: 'basic',
        title: 'SSIS Package',
        type: 'collapse',
        icon: 'feather icon-server',
        children: [
          {
            id: 'createconfiguration',
            title: 'Create configuration',
            type: 'item',
            url: '/ssispackage/createconfiguration'
          },
          {
            id: 'createbatch',
            title: 'Create Batch File',
            type: 'item',
            url: '/ssispackage/createbatch'
          },
          {
            id: 'mappackage',
            title: 'Package Mapping',
            type: 'item',
            url: '/ssispackage/mappackage'
          },
          {
            id: 'packagedeployment',
            title: 'Package Deployment',
            type: 'item',
            url: '/ssispackage/packagedeployment'
          }
        ]
      }
    ]
  }
  // ,
  // {
  //   id: 'Authentication',
  //   title: 'Authentication',
  //   type: 'group',
  //   icon: 'icon-group',
  //   children: [
  //     {
  //       id: 'signup',
  //       title: 'Sign up',
  //       type: 'item',
  //       url: '/auth/signup',
  //       icon: 'feather icon-at-sign',
  //       target: true,
  //       breadcrumbs: false
  //     },
  //     {
  //       id: 'signin',
  //       title: 'Sign in',
  //       type: 'item',
  //       url: '/auth/signin',
  //       icon: 'feather icon-log-in',
  //       target: true,
  //       breadcrumbs: false
  //     }
  //   ]
  // },
  // {
  //   id: 'chart',
  //   title: 'Chart',
  //   type: 'group',
  //   icon: 'icon-group',
  //   children: [
  //     {
  //       id: 'apexchart',
  //       title: 'ApexChart',
  //       type: 'item',
  //       url: '/chart',
  //       classes: 'nav-item',
  //       icon: 'feather icon-pie-chart'
  //     }
  //   ]
  // },
  // {
  //   id: 'forms & tables',
  //   title: 'Forms & Tables',
  //   type: 'group',
  //   icon: 'icon-group',
  //   children: [
  //     {
  //       id: 'forms',
  //       title: 'Basic Elements',
  //       type: 'item',
  //       url: '/forms',
  //       classes: 'nav-item',
  //       icon: 'feather icon-file-text'
  //     },
  //     {
  //       id: 'tables',
  //       title: 'tables',
  //       type: 'item',
  //       url: '/tables',
  //       classes: 'nav-item',
  //       icon: 'feather icon-server'
  //     }
  //   ]
  // }  
];
