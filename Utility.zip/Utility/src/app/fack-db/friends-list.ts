export class FriendsList {
  public static friends = [
    {
      id: 1,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Josephin Doe',
      new: 3,
      status: 1,
      time: 'typing'
    },
    {
      id: 2,
      photo: 'assets/images/user/avatar-2.jpg',
      name: 'Lary Doe',
      new: 1,
      status: 1,
      time: 'online'
    },
    {
      id: 3,
      photo: 'assets/images/user/avatar-3.jpg',
      name: 'Alice',
      status: 1,
      time: 'online'
    },
    {
      id: 4,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Alia',
      status: 0,
      new: 1,
      time: '10 min ago'
    },
    {
      id: 5,
      photo: 'assets/images/user/avatar-4.jpg',
      name: 'Suzen',
      status: 0,
      time: '15 min ago'
    },
    {
      id: 1,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Josephin Doe',
      new: 3,
      status: 1,
      time: 'typing'
    },
    {
      id: 2,
      photo: 'assets/images/user/avatar-2.jpg',
      name: 'Lary Doe',
      new: 1,
      status: 1,
      time: 'online'
    },
    {
      id: 3,
      photo: 'assets/images/user/avatar-3.jpg',
      name: 'Alice',
      status: 1,
      time: 'online'
    },
    {
      id: 4,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Alia',
      status: 0,
      new: 1,
      time: '10 min ago'
    },
    {
      id: 5,
      photo: 'assets/images/user/avatar-4.jpg',
      name: 'Suzen',
      status: 0,
      time: '15 min ago'
    },
    {
      id: 1,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Josephin Doe',
      new: 3,
      status: 1,
      time: 'typing'
    },
    {
      id: 2,
      photo: 'assets/images/user/avatar-2.jpg',
      name: 'Lary Doe',
      new: 1,
      status: 1,
      time: 'online'
    },
    {
      id: 3,
      photo: 'assets/images/user/avatar-3.jpg',
      name: 'Alice',
      status: 1,
      time: 'online'
    },
    {
      id: 4,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Alia',
      status: 0,
      new: 1,
      time: '10 min ago'
    },
    {
      id: 5,
      photo: 'assets/images/user/avatar-4.jpg',
      name: 'Suzen',
      status: 0,
      time: '15 min ago'
    },
    {
      id: 1,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Josephin Doe',
      new: 3,
      status: 1,
      time: 'typing'
    },
    {
      id: 2,
      photo: 'assets/images/user/avatar-2.jpg',
      name: 'Lary Doe',
      new: 1,
      status: 1,
      time: 'online'
    },
    {
      id: 3,
      photo: 'assets/images/user/avatar-3.jpg',
      name: 'Alice',
      status: 1,
      time: 'online'
    },
    {
      id: 4,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Alia',
      status: 0,
      new: 1,
      time: '10 min ago'
    },
    {
      id: 5,
      photo: 'assets/images/user/avatar-4.jpg',
      name: 'Suzen',
      status: 0,
      time: '15 min ago'
    },
    {
      id: 1,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Josephin Doe',
      new: 3,
      status: 1,
      time: 'typing'
    },
    {
      id: 2,
      photo: 'assets/images/user/avatar-2.jpg',
      name: 'Lary Doe',
      new: 1,
      status: 1,
      time: 'online'
    },
    {
      id: 3,
      photo: 'assets/images/user/avatar-3.jpg',
      name: 'Alice',
      status: 1,
      time: 'online'
    },
    {
      id: 4,
      photo: 'assets/images/user/avatar-1.jpg',
      name: 'Alia',
      status: 0,
      new: 1,
      time: '10 min ago'
    },
    {
      id: 5,
      photo: 'assets/images/user/avatar-4.jpg',
      name: 'Suzen',
      status: 0,
      time: '15 min ago'
    }
  ];
}
