// Angular Import
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// project import
import { AdminComponent } from './theme/layout/admin/admin.component';
import { GuestComponent } from './theme/layout/guest/guest.component';

const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: '',
        redirectTo: '/analytics',
        pathMatch: 'full'
      },
      {
        path: 'analytics',
        loadComponent: () => import('./ui-components/dashboard/dash-analytics/dash-analytics.component')
      },
      {
        path: 'files',
        loadChildren: () => import('./ui-components/ui-element/admin-files/files.module').then((m) => m.UiBasicFileProcessModule)
      },
      {
        path: 'scripts',
        loadChildren: () => import('./ui-components/ui-element/admin-files/scripts.module').then((m) => m.UiBasicScriptsProcessModule)
      },
      {
        path: 'ssispackage',
        loadChildren: () => import('./ui-components/ui-element/admin-files/ssispackage.module').then((m) => m.UiBasicSSISPackageModule)
      },
      {
        path: 'component',
        loadChildren: () => import('./ui-components/ui-element/ui-basic.module').then((m) => m.UiBasicModule)
      },
      {
        path: 'chart',
        loadComponent: () => import('./ui-components/chart & map/core-apex/core-apex.component')
      },
      {
        path: 'forms',
        loadComponent: () => import('./ui-components/forms & tables/form-elements/form-elements.component')
      },
      {
        path: 'tables',
        loadComponent: () => import('./ui-components/forms & tables/tbl-bootstrap/tbl-bootstrap.component')
      }      
    ]
  },
  {
    path: '',
    component: GuestComponent,
    children: [
      {
        path: 'auth/signup',
        loadComponent: () => import('./ui-components/authentication/sign-up/sign-up.component')
      },
      {
        path: 'auth/signin',
        loadComponent: () => import('./ui-components/authentication/sign-in/sign-in.component')
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
