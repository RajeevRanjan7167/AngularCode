import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-packageDeployment',
  templateUrl: './packageDeployment.component.html',
  styleUrls: ['./packageDeployment.component.css']
})
export class PackageDeploymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
