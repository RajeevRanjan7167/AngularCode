import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createConfiguration',
  templateUrl: './createConfiguration.component.html',
  styleUrls: ['./createConfiguration.component.css']
})
export class CreateConfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
