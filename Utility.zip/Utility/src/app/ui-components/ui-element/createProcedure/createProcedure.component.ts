import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/theme/shared/shared.module';

@Component({
  standalone: true,
  imports: [CommonModule, SharedModule],
  selector: 'app-createProcedure',
  templateUrl: './createProcedure.component.html',
  styleUrls: ['./createProcedure.component.css']
})
export class CreateProcedureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
