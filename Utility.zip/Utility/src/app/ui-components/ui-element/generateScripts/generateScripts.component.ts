import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/theme/shared/shared.module';

@Component({
  standalone: true,
  imports: [CommonModule, SharedModule],
  selector: 'app-generateScripts',
  templateUrl: './generateScripts.component.html',
  styleUrls: ['./generateScripts.component.css']
})
export class GenerateScriptsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
