import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/theme/shared/shared.module';

@Component({
  standalone: true,
  imports: [CommonModule, SharedModule],
  selector: 'app-updateOutput',
  templateUrl: './updateOutput.component.html',
  styleUrls: ['./updateOutput.component.css']
})
export class UpdateOutputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
