import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/theme/shared/shared.module';
import { ConfigService } from 'src/app/ui-components/services/config.service';

@Component({
  standalone: true,
  imports: [CommonModule, SharedModule],
  selector: 'app-fileProcess',
  templateUrl: './fileProcess.component.html',
  styleUrls: ['./fileProcess.component.css']
})
export class FileProcessComponent implements OnInit {

  constructor(private config: ConfigService) { }

  ngOnInit() {

    // this.config.getData().subscribe(data => {
    //   console.log(data);
    // });

    this.allFileReadFromDirectory()
  }


  allFileReadFromDirectory() {

  }

}
