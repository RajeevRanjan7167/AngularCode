import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mapPackage',
  templateUrl: './mapPackage.component.html',
  styleUrls: ['./mapPackage.component.css']
})
export class MapPackageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
