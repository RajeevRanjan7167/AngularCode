import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/theme/shared/shared.module';

@Component({
  standalone: true,
  imports: [CommonModule, SharedModule],
  selector: 'app-fileUpdate',
  templateUrl: './fileUpdate.component.html',
  styleUrls: ['./fileUpdate.component.css']
})
export class FileUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
