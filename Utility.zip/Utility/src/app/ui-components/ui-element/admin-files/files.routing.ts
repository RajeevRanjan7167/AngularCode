import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FileProcessComponent } from '../fileProcess/fileProcess.component';
import { FileUpdateComponent } from '../fileUpdate/fileUpdate.component';

const routes: Routes = [
  { path: 'fileprocess', component: FileProcessComponent },
  { path: 'fileupdate', component: FileUpdateComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UiBasicFileProcessRouteModule { }
