import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UpdateOutputComponent } from '../updateOutput/updateOutput.component';
import { GenerateScriptsComponent } from '../generateScripts/generateScripts.component';
import { CreateProcedureComponent } from '../createProcedure/createProcedure.component';

const routes: Routes = [
  { path: 'updateoutput', component: UpdateOutputComponent },
  { path: 'generatescripts', component: GenerateScriptsComponent },
  { path: 'createprocedure', component: CreateProcedureComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UiBasicScriptsProcessRouteModule { }