import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { UiBasicFileProcessRouteModule } from './files.routing';
import { ConfigService } from 'src/app/ui-components/services/config.service';


@NgModule({
  declarations: [],
  imports: [CommonModule, UiBasicFileProcessRouteModule,HttpClientModule],
  providers: [ConfigService]
})
export class UiBasicFileProcessModule {}