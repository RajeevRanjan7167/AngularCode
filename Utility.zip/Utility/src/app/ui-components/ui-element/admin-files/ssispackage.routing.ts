import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateConfigurationComponent } from '../createConfiguration/createConfiguration.component';
import { CreateBatchComponent } from '../createBatch/createBatch.component';
import { MapPackageComponent } from '../mapPackage/mapPackage.component';
import { PackageDeploymentComponent } from '../packageDeployment/packageDeployment.component';

const routes: Routes = [
  { path: 'createconfiguration', component: CreateConfigurationComponent },
  { path: 'createbatch', component: CreateBatchComponent },
  { path: 'mappackage', component: MapPackageComponent },
  { path: 'packagedeployment', component: PackageDeploymentComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UiBasicSSISPackageRouteModule { }
