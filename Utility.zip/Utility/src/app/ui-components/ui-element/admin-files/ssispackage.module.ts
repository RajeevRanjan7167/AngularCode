import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UiBasicSSISPackageRouteModule } from './ssispackage.routing';

@NgModule({
  declarations: [],
  imports: [CommonModule, UiBasicSSISPackageRouteModule]
})
export class UiBasicSSISPackageModule {}