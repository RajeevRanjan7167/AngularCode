import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createBatch',
  templateUrl: './createBatch.component.html',
  styleUrls: ['./createBatch.component.css']
})
export class CreateBatchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
